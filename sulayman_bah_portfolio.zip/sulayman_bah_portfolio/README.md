# Sulayman Bah — Personal Portfolio

A responsive, single-page portfolio website built with HTML, CSS and JavaScript.

## Preview locally
1. Extract the ZIP (if downloaded).
2. Open `index.html` in your browser.

## Publish for free with GitHub Pages
1. Create a GitHub repository, for example `sulayman-bah-portfolio`.
2. Upload `index.html` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
5. GitHub will provide your public website URL.

## Before publishing
- Replace the generic GitHub links with your actual profile/repository URLs.
- Add links for the Movie Recommendation System and Fashion-MNIST projects.
- Check your contact details and project descriptions.
